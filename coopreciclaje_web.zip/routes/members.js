
const express=require("express");
const router=express.Router();
const db=require("../database");

router.post("/",(req,res)=>{

const {name,email,phone,city}=req.body;

db.get("SELECT email FROM members WHERE email=?",[email],(err,row)=>{

if(row){
return res.json({error:"This contact already exists."});
}

db.run(`INSERT INTO members(name,email,phone,city)
VALUES(?,?,?,?)`,
[name,email,phone,city],
()=>res.json({success:true})
);

});

});

module.exports=router;
