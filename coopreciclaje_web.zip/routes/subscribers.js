
const express=require("express");
const router=express.Router();
const db=require("../database");

router.post("/",(req,res)=>{

const {name,email}=req.body;

db.get("SELECT email FROM subscribers WHERE email=?",[email],(err,row)=>{

if(row){
return res.json({error:"Already subscribed"});
}

db.run("INSERT INTO subscribers(name,email) VALUES(?,?)",
[name,email],
()=>res.json({success:true})
);

});

});

module.exports=router;
