
const express=require("express");
const router=express.Router();
const db=require("../database");

router.post("/",(req,res)=>{

const {name,email,phone,message}=req.body;

db.run(`INSERT INTO contacts(name,email,phone,message)
VALUES(?,?,?,?)`,
[name,email,phone,message],
()=>res.json({success:true})
);

});

module.exports=router;
