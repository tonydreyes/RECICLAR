
const sqlite3 = require("sqlite3").verbose();
const db = new sqlite3.Database("./database/coopreciclaje.db");

db.serialize(()=>{

db.run(`CREATE TABLE IF NOT EXISTS articles(
id INTEGER PRIMARY KEY AUTOINCREMENT,
title TEXT,
image TEXT,
summary TEXT,
content TEXT,
author TEXT,
date TEXT,
category TEXT,
slug TEXT UNIQUE,
tags TEXT
)`);

db.run(`CREATE TABLE IF NOT EXISTS members(
id INTEGER PRIMARY KEY AUTOINCREMENT,
name TEXT,
email TEXT UNIQUE,
phone TEXT,
city TEXT
)`);

db.run(`CREATE TABLE IF NOT EXISTS subscribers(
id INTEGER PRIMARY KEY AUTOINCREMENT,
name TEXT,
email TEXT UNIQUE
)`);

db.run(`CREATE TABLE IF NOT EXISTS contacts(
id INTEGER PRIMARY KEY AUTOINCREMENT,
name TEXT,
email TEXT,
phone TEXT,
message TEXT
)`);

});

module.exports = db;
